package com.nissan.exception;

@SuppressWarnings("serial")
public class UserCustomException extends Exception {

	public UserCustomException(String message) {
		super(message);
	}

}
