package com.nissan.exception;

@SuppressWarnings("serial")
public class PurchaseOrderCustomException extends Exception{
	public PurchaseOrderCustomException(String message){
		super(message);
		
	}

}
