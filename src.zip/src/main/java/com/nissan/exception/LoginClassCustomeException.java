package com.nissan.exception;

@SuppressWarnings("serial")
public class LoginClassCustomeException extends Exception {

	public LoginClassCustomeException(String message) {
		super(message);
	}

}
